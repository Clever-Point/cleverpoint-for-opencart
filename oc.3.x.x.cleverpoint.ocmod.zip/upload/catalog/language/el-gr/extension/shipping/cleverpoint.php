<?php
// Text
$_['text_title']       = 'Clever Point';
$_['text_description'] = 'Παραλαβή από σημείο Clever Point';
$_['error_cleverpoint'] 	= 'Δεν έχετε επιλέξει σταθμό Cleverpoint!';
$_['error_cleverpoint_method'] 	= 'Δεν έχετε επιλέξει μέθοδο αποστολής Cleverpoint!';
$_['cleverpoint_shipping_cost'] 	= 'Κόστος Μεταφορικών';
$_['cleverpoint_fee_cost'] 	= 'Κόστος Υπηρεσίας';
$_['text_selected_point'] 	= 'Επιλεγμένο σημείο';

$_['text_cleverpoint_modal_btn'] = 'Επιλογή σημείου <b>Clever Point</b>';
$_['text_confirm_cleverpoint'] 	= 'Επιβεβαίωση';
$_['text_cancel_cleverpoint'] 	= 'Κλείσιμο';